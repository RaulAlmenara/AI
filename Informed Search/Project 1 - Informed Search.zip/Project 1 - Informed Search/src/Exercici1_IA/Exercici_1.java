package Exercici1_IA;

import java.util.Scanner;
import java.util.LinkedList;
import java.util.List;

public class Exercici_1 {

    public static Punt[][] mapa_enunciat = {
            {new Punt(0, 0, 1), new Punt(0, 1, 0), new Punt(0, 2, -1), new Punt(0, 3, 1), new Punt(0, 4, 3), new Punt(0, 5, 2), new Punt(0, 6, 3), new Punt(0, 7, 4), new Punt(0, 8, 3), new Punt(0, 9, 1)},
            {new Punt(1, 0, 2), new Punt(1, 1, 1), new Punt(1, 2, -1), new Punt(1, 3, 2), new Punt(1, 4, 4), new Punt(1, 5, 2), new Punt(1, 6, 2), new Punt(1, 7, 4), new Punt(1, 8, 2), new Punt(1, 9, 2)},
            {new Punt(2, 0, 5), new Punt(2, 1, 3), new Punt(2, 2, -1), new Punt(2, 3, 2), new Punt(2, 4, 3), new Punt(2, 5, 2), new Punt(2, 6, -1), new Punt(2, 7, 3), new Punt(2, 8, 3), new Punt(2, 9, 3)},
            {new Punt(3, 0, 3), new Punt(3, 1, 3), new Punt(3, 2, 1), new Punt(3, 3, 3), new Punt(3, 4, 4), new Punt(3, 5, 3), new Punt(3, 6, -1), new Punt(3, 7, 1), new Punt(3, 8, 2), new Punt(3, 9, 2)},
            {new Punt(4, 0, 2), new Punt(4, 1, 2), new Punt(4, 2, 2), new Punt(4, 3, 3), new Punt(4, 4, 6), new Punt(4, 5, 4), new Punt(4, 6, -1), new Punt(4, 7, 1), new Punt(4, 8, 2), new Punt(4, 9, 1)},
            {new Punt(5, 0, -1), new Punt(5, 1, -1), new Punt(5, 2, -1), new Punt(5, 3, -1), new Punt(5, 4, 3), new Punt(5, 5, 3), new Punt(5, 6, -1), new Punt(5, 7, 0), new Punt(5, 8, 2), new Punt(5, 9, -1)},
            {new Punt(6, 0, -1), new Punt(6, 1, -1), new Punt(6, 2, -1), new Punt(6, 3, -1), new Punt(6, 4, 2), new Punt(6, 5, 4), new Punt(6, 6, -1), new Punt(6, 7, 2), new Punt(6, 8, 2), new Punt(6, 9, -1)},
            {new Punt(7, 0, 2), new Punt(7, 1, 3), new Punt(7, 2, 4), new Punt(7, 3, 3), new Punt(7, 4, 1), new Punt(7, 5, 3), new Punt(7, 6, -1), new Punt(7, 7, 3), new Punt(7, 8, 2), new Punt(7, 9, -1)},
            {new Punt(8, 0, 3), new Punt(8, 1, 5), new Punt(8, 2, 6), new Punt(8, 3, 5), new Punt(8, 4, 2), new Punt(8, 5, 3), new Punt(8, 6, -1), new Punt(8, 7, 5), new Punt(8, 8, 3), new Punt(8, 9, -1)},
            {new Punt(9, 0, 5), new Punt(9, 1, 6), new Punt(9, 2, 7), new Punt(9, 3, 6), new Punt(9, 4, 4), new Punt(9, 5, 4), new Punt(9, 6, -1), new Punt(9, 7, 6), new Punt(9, 8, 4), new Punt(9, 9, 5)}
    };

  /*  public static Punt[][] mapa_enunciat = {
            {new Punt(0, 0, 5), new Punt(0, 1, 1), new Punt(0, 2, -1), new Punt(0, 3, -1), new Punt(0, 4, 3), new Punt(0, 5, 1), new Punt(0, 6, 3), new Punt(0, 7, 4), new Punt(0, 8, 3), new Punt(0, 9, 1)},
            {new Punt(1, 0, 0), new Punt(1, 1, 2), new Punt(1, 2, -1), new Punt(1, 3, -1), new Punt(1, 4, 2), new Punt(1, 5, 2), new Punt(1, 6, 2), new Punt(1, 7, 4), new Punt(1, 8, 2), new Punt(1, 9, 2)},
            {new Punt(2, 0, 1), new Punt(2, 1, 3), new Punt(2, 2, -1), new Punt(2, 3, -1), new Punt(2, 4, 1), new Punt(2, 5, 3), new Punt(2, 6, 2), new Punt(2, 7, 3), new Punt(2, 8, 3), new Punt(2, 9, 3)},
            {new Punt(3, 0, 3), new Punt(3, 1, 3), new Punt(3, 2, 1), new Punt(3, 3, 3), new Punt(3, 4, 4), new Punt(3, 5, 4), new Punt(3, 6, 3), new Punt(3, 7, -1), new Punt(3, 8, -1), new Punt(3, 9, 2)},
            {new Punt(4, 0, 2), new Punt(4, 1, 2), new Punt(4, 2, 2), new Punt(4, 3, 1), new Punt(4, 4, 6), new Punt(4, 5, 4), new Punt(4, 6, 7), new Punt(4, 7, -1), new Punt(4, 8, 2), new Punt(4, 9, 1)},
            {new Punt(5, 0, 1), new Punt(5, 1, 1), new Punt(5, 2, -1), new Punt(5, 3, 0), new Punt(5, 4, 3), new Punt(5, 5, 3), new Punt(5, 6, 5), new Punt(5, 7, -1), new Punt(5, 8, 2), new Punt(5, 9, -1)},
            {new Punt(6, 0, 1), new Punt(6, 1, 1), new Punt(6, 2, -1), new Punt(6, 3, 1), new Punt(6, 4, 2), new Punt(6, 5, 2), new Punt(6, 6, 6), new Punt(6, 7, -1), new Punt(6, 8, 2), new Punt(6, 9, -1)},
            {new Punt(7, 0, 1), new Punt(7, 1, 0), new Punt(7, 2, 0), new Punt(7, 3, 3), new Punt(7, 4, -1), new Punt(7, 5, 2), new Punt(7, 6, -1), new Punt(7, 7, 4), new Punt(7, 8, 2), new Punt(7, 9, -1)},
            {new Punt(8, 0, 3), new Punt(8, 1, 2), new Punt(8, 2, 1), new Punt(8, 3, 3), new Punt(8, 4, -1), new Punt(8, 5, -1), new Punt(8, 6, -1), new Punt(8, 7, 5), new Punt(8, 8, 3), new Punt(8, 9, -1)},
            {new Punt(9, 0, 5), new Punt(9, 1, 2), new Punt(9, 2, 1), new Punt(9, 3, 4), new Punt(9, 4, -1), new Punt(9, 5, -1), new Punt(9, 6, -1), new Punt(9, 7, 6), new Punt(9, 8, 4), new Punt(9, 9, 5)}
    };*/


    public static void main(String[] args) {
        List<Punt> path;
        Scanner reader = new Scanner(System.in);
        System.out.println("Escull l'algorisme que prefereixis: \n 1. BestFirst \n 2. A*");
        int heuristic = 0;
        int option_algorithm = reader.nextInt();

        switch(option_algorithm){
            case 1:
                System.out.println("Escull la heurística preferida: \n 1. Diferència de alçada entre punt actual i final \n 2. Distància diagonal \n 3. Segons el valor del temps entre el punt actual i el final");
                int option_heuristic = reader.nextInt();

                switch(option_heuristic){
                    case 1: heuristic = 1; break;
                    case 2: heuristic = 2; break;
                    case 3: heuristic = 3; break;
                }

                BestFirst bestfirst = new BestFirst();

                path = bestfirst.path(mapa_enunciat, new Punt(0, 0, 1), new Punt(9, 9, 5), heuristic);

                System.out.println(path.get(0).printPath());
                System.out.println("El total de caselles recorregudes ha estat: "+bestfirst.getVisitedNodes());
                System.out.println("El temps total ha estat: "+path.get(0).getTime());

                break;

            case 2:
                System.out.println("Escull la heurística preferida: \n 1. Diferència de alçada entre punt actual i final \n 2. Distància diagonal \n 3. Segons el valor del temps entre el punt actual i el final");
                int option_heuristic2 = reader.nextInt();

                switch(option_heuristic2){
                    case 1: heuristic = 1; break;
                    case 2: heuristic = 2; break;
                    case 3: heuristic = 3; break;
                }
                A_estrella a_estrella = new A_estrella();

                path =  a_estrella.path(mapa_enunciat, new Punt(0, 0, 1), new Punt(9, 9, 5), heuristic);

                System.out.println(path.get(0).printPath());
                System.out.println("El total de caselles recorregudes ha estat: "+a_estrella.getVisitedNodes());
                System.out.println("El temps total ha estat: "+path.get(0).getTime());

                break;
        }
    }
}








