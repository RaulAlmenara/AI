package Exercici1_IA;

import java.util.List;

interface Algoritme {
    List<Punt> path(Punt[][] map, Punt initialPoint, Punt finalPoint, int heuristica);
    double h1(Punt point, Punt end);
    double h2(Punt point, Punt end);
    double h3(Punt point, Punt end);
    boolean Visited(Punt point);
    int getVisitedNodes();
    }
