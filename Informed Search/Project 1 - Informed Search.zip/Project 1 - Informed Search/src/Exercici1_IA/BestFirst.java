package Exercici1_IA;

import com.sun.corba.se.impl.oa.poa.POAImpl;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class BestFirst implements Algoritme {
    public int costHeuristica = 0;
    public double time;
    LinkedList<Punt> visitedPoints = new LinkedList<>();
    PriorityQueue<Punt> pendingPoints = new PriorityQueue();

    public List<Punt> path(Punt[][] map, Punt initialPoint, Punt finalPoint, int heuristica){
        boolean found = false;
        Punt actualPoint = null;
        pendingPoints.add(initialPoint);

        while(!found && !pendingPoints.isEmpty()){
            actualPoint = pendingPoints.poll();
            if(actualPoint.getX() == finalPoint.getX() && actualPoint.getY() == finalPoint.getY()){
                found = true;
            }
            else{
                List<Punt> pointsNear = getPointsNear(map, actualPoint);

                for(Punt point : pointsNear){
                 if(!pendingPoints.contains(point) && !Visited(point)){

                     if(point.getValue() < actualPoint.getValue()){
                         time = 0.5;
                     }
                     else{
                         time = (point.getValue() - actualPoint.getValue()) + 1;
                     }

                     point.addToPath(actualPoint.getPath());
                     point.setPath(actualPoint);
                     point.setTime(actualPoint.getTime() + time);
                     switch (heuristica){
                         case 1:
                             point.setValorHeuristica(h1(point, finalPoint));
                             break;
                         case 2:
                             point.setValorHeuristica(h2(point, finalPoint));
                             break;
                         case 3:
                             point.setValorHeuristica(h3(point, finalPoint));
                             break;
                     }
                     pendingPoints.add(point);
                   }
                }
                if(!Visited(actualPoint))visitedPoints.add(actualPoint);
                costHeuristica++; //numero de caselles per les que s'ha pasat
            }
        }
        if(found){
           return actualPoint.getPath();
        }
        else{
            System.out.println("No existeix cami");
            return null;
        }
    }

    public List<Punt> getPointsNear(Punt[][] map, Punt actualPoint){
        LinkedList<Punt> pointsNear = new LinkedList<>();
        int actualX = actualPoint.getX();
        int actualY = actualPoint.getY();

        //si els punts contigus estan fora de rang, son acantilats o ja estan visitats, no s'agafaen
        //punt esquerre
        if((actualX - 1 >= 0) && map[actualX - 1][actualY].getValue() > -1) pointsNear.add(new Punt(actualX - 1, actualY, map[actualX - 1][actualY].getValue()));
        //punt dret
        if((actualX + 1 < map.length) && map[actualX + 1][actualY].getValue() > -1) pointsNear.add(new Punt(actualX + 1, actualY, map[actualX + 1][actualY].getValue()));
        //punt a dalt
        if((actualY - 1 >= 0) && map[actualX][actualY - 1].getValue() > -1) pointsNear.add(new Punt(actualX, actualY - 1, map[actualX][actualY - 1].getValue()));
        //punt a baix
        if((actualY + 1 < map[0].length) && map[actualX][actualY + 1].getValue() > -1) pointsNear.add(new Punt(actualX, actualY + 1, map[actualX][actualY + 1].getValue()));

        return pointsNear;
    }

    public boolean Visited(Punt point){
        for(Punt p : visitedPoints){
            if(p.getX() == point.getX() && p.getY() == point.getY()) return true;
        }
        return false;
    }

    public double h1(Punt point, Punt end){
        return (end.getY() - point.getY());
    }

    public double h2(Punt point, Punt end){
        double distanceX = end.getX() - point.getX();
        double distanceY = end.getY() - point.getY();
        return (Math.sqrt(Math.pow(distanceX, 2) + Math.pow(distanceY, 2)));
    }

    public double h3(Punt point, Punt end){
        if(end.getValue() < point.getValue()) return 0.5;
        else return ((end.getValue() - point.getValue()) + 1);
    }

    public int getVisitedNodes() {
        return visitedPoints.size();
    }

}
