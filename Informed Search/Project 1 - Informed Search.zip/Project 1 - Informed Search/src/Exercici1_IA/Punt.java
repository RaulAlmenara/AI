package Exercici1_IA;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Punt implements Comparable<Punt>{
    private int x;
    private int y;
    private int value;
    private float time;
    private double valorHeuristica;
    private List<Punt> path;
    private Punt previous;


    public Punt(int x, int y, int value){
        this.x = x;
        this.y = y;
        this.value = value;
        this.time = 0;
        this.path = new LinkedList<Punt>();
        this.path.add(this);
    }


    public int getX(){ return this.x;}
    public int getY(){ return this.y;}
    public int getValue(){ return this.value;}
    public double getTime() { return this.time;}
    public double getValorHeuristica(){ return this.valorHeuristica;}
    public List<Punt> getPath(){return this.path;}

    public void setX(int x){ this.x = x;}
    public void setY(int y){ this.y = y;}
    public void setValue(int value){ this.value = value;}
    public void setTime(double time){ this.time += time;}
    public void setValorHeuristica(double valorHeuristica){  this.valorHeuristica = valorHeuristica;}
    public void setPath(Punt point){ previous = point;}


    public int compareTo(Punt punt) {
        if(this.getValorHeuristica() <= punt.getValorHeuristica()){
            return -1;
        }
        else if(this.getValorHeuristica() > punt.getValorHeuristica()){
            return 1;
        }
        return 0;
    }

    public void addToPath(List<Punt> path){
        this.path.addAll(path);
    }

    public String printPath(){
        return(((previous !=null) ? previous.printPath() : "") + "\nX: "+x+" Y: "+y+" Value: "+value);
    }

    public float printTime(){
        return(((previous !=null) ? previous.printTime() : 0));
    }
}
